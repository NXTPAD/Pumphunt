/* NXT Pump Bot settings. Only change what's inside the quotes.
   Keep every quote mark and the comma at the end of each line. */
window.NXT_BOT_CONFIG = {
  // Solana RPC. Paste your Helius mainnet URL here (the same key as NXT DEX works;
  // add this site's domain to the key's allowed domains).
  SOLANA_RPC: "https://api.mainnet-beta.solana.com",

  // Jupiter swaps. With a Jupiter key, change JUPITER_API to "https://api.jup.ag".
  JUPITER_API: "https://lite-api.jup.ag",
  JUPITER_KEY: "",

  // New-coin data (GeckoTerminal, free, no key).
  GECKO_API: "https://api.geckoterminal.com/api/v2",

  // Rug checks go through this site's own /api/rug function (in the functions folder).
  RUGCHECK_API: "/api/rug",

  // Your Solana wallet that receives bot fees. Leave empty to charge no fee.
  TREASURY_SOL: "",

  // Fees in basis points (100 = 1%).
  FEE_STANDARD_BPS: 100,
  FEE_HOLDER_BPS: 50,

  // Paste the NXT token address here the second it launches.
  NXT_TOKEN: { address: "", decimals: 6 },

  // Live trading opens at this time (Central time). Practice mode works any time.
  LAUNCH_AT: "2026-10-03T00:00:00-05:00",

  // Starting balance for practice mode.
  PRACTICE_START_SOL: 1,

  // Links
  DEX_URL: "",
  MAIN_BOT_URL: "",  // link to NXT Bot (all coins)
  CLOUD_URL: ""
};

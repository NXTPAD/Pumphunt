# NXT Pump Bot: setup

NXT Pump Bot is the pump.fun-only version of NXT Bot: same design, controls and wallet system, but it only watches and trades pump.fun coins (on the bonding curve and after they graduate to PumpSwap). It's a static site plus one small Cloudflare function, with no build step.

Deploy it as its **own** GitHub repo and Cloudflare Pages project (for example `nxt-pump-bot`, or a domain like `pump.yourdomain.com`), separate from NXT Bot. Each bot keeps its own settings, practice account and bot wallet.

## 1. Put it on GitHub
1. Create a new repository on github.com called `nxt-pump-bot`.
2. Click **Add file → Upload files**.
3. Open the unzipped `nxt-pump-bot` folder, select **everything inside it**, and drag it in. Don't drag the folder itself.
4. Commit.

Worked when: `index.html`, `app.js`, `config.js` and the `functions` folder are at the top level of the repo.

## 2. Connect Cloudflare Pages
1. dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → pick `nxt-pump-bot`.
2. Framework preset: **None**. Build command: **empty**. Output directory: **/** (or leave empty).
3. Save and deploy. Add a custom domain later if you want one (for example `bot.yourdomain.com`).

Worked when: the site opens and the Scanner tab fills with new pump.fun coins within a minute.

## 3. Edit config.js (on GitHub, pencil icon)
| Setting | What to put |
|---|---|
| `SOLANA_RPC` | Your Helius mainnet URL (`https://mainnet.helius-rpc.com/?api-key=…`). The same key as NXT DEX works. In Helius, add the bot's domain to the key's allowed domains. **Needed**: the free public RPC blocks most browser traffic. |
| `JUPITER_API` / `JUPITER_KEY` | Optional. With a key from portal.jup.ag, set `JUPITER_API: "https://api.jup.ag"` and paste the key. |
| `TREASURY_SOL` | Your Solana wallet for bot fees. If it's empty, no fee is charged. |
| `FEE_STANDARD_BPS` / `FEE_HOLDER_BPS` | 100 = 1%, 50 = 0.5%. |
| `NXT_TOKEN.address` | Paste the NXT contract address the second it launches. Holders then get the lower fee. |
| `MAIN_BOT_URL` | Optional link to NXT Bot, shown when someone taps the pump.fun button in the header. |
| `LAUNCH_AT` | When live trading unlocks. Already set to Oct 3, 2026, 00:00 Central. |

Keep every quote mark and comma. A typo blanks the site. If that happens, compare config.js with its previous version in GitHub's History.

## 4. Test before Oct 3
- **Practice mode** works now for everyone. Click **Start practice bot** and leave the tab open for 10–20 minutes. You should see buys, skipped rugs and take-profit/stop-loss sells in Activity.
- **Live mode early**: add `#preview` to the end of the address. Switch to Live → **Create** a bot wallet → **Export key** and save it → **Deposit** 0.1 SOL from Phantom → buy one coin by hand from the Scanner with a tiny buy size (0.01 SOL) → sell it from the Dashboard. Check the transactions on Solscan and that the fee reached your treasury.

## Main controls (Dashboard)
- **Buy size**, **Take-profit**, **Sell at take-profit** (how much of the coin to sell, 1–100%) and **Stop-loss** sit on the Auto-trader card. Type a number or tap a preset; it saves right away and applies to the next check.
- **Which pump.fun coins to buy**: *Any new coin*, *Balanced* or *Strict*.
- **Stage**: *Bonding curve* (still on pump.fun's curve), *Graduated* (moved to PumpSwap) or *Both*. Fine-tune everything else on the Strategy tab.
- Copy trading is optional, at the bottom of the Strategy tab, and only copies pump.fun coins.

## Buy every launch (no filters)
- Turn on **Buy every new launch** on the Auto-trader card. The bot then buys a fixed dollar amount (default $1) of every new pump.fun coin the second it launches, with no filters, and sells each one at your take-profit, stop-loss or after the "Sell after" time.
- **Max buys per hour** and **Max coins held** are your spending limits. pump.fun gets hundreds of launches an hour, so without them the bot would buy all of them.
- Launches come from PumpPortal's free live feed. Trades are built by PumpPortal through this site's `/api/pumptx` function and signed in the browser. PumpPortal charges its own fee on these trades (listed on pumpportal.fun).
- In live mode, every buy also pays network fees plus about 0.002 SOL of token-account rent. The bot closes the empty account after a full sell to get the rent back.

## "Is it working?" panel (Dashboard)
Shows a green or red light for the launch feed, the Solana connection, Jupiter, GeckoTerminal and rug checks, with what to fix. The most common problem is the Solana connection: the default public RPC blocks browsers, so paste your Helius link into `SOLANA_RPC`. The Scanner tab also lists every launch as it happens and what the bot did with it.

## How it works (what to tell users)
- **Non-custodial.** Each user's bot wallet key is created in their own browser and never sent anywhere. Users can export it to Phantom at any time.
- **Runs while the page is open.** The bot scans, buys and sells from the open tab. Phones and background tabs slow it down, so a computer with the tab kept open works best.
- **Clearing browser data deletes the bot key.** Users must back it up with Export key.
- **Data sources:** GeckoTerminal (new pools), RugCheck through `/api/rug` plus on-chain mint and freeze checks, and Jupiter (prices, sell-route test and swaps).

## Not built yet
- Robinhood Chain trading (shown as "Coming soon"). It can be added once its mainnet details are public.
- 24/7 trading with the tab closed. That needs the bot key on a server, which is no longer non-custodial. If you want it later as an opt-in, it's a separate build (Cloudflare Worker + Cron + encrypted keys).

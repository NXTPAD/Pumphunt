// Cloudflare Pages Function: POST /api/pumptx
// Asks PumpPortal to build an unsigned pump.fun buy/sell transaction for the user's bot wallet.
// The transaction is signed in the user's browser; no keys ever reach this function.
export async function onRequestPost({ request }) {
  let b;
  try { b = await request.json(); } catch (e) { return err("Bad request", 400); }
  const ok = b && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(b.publicKey || "") && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(b.mint || "") && (b.action === "buy" || b.action === "sell");
  if (!ok) return err("Invalid trade request", 400);
  const body = {
    publicKey: b.publicKey, action: b.action, mint: b.mint, amount: b.amount,
    denominatedInSol: b.denominatedInSol === "true" ? "true" : "false",
    slippage: Math.min(50, Math.max(1, Number(b.slippage) || 15)),
    priorityFee: Math.min(0.01, Math.max(0, Number(b.priorityFee) || 0.0005)),
    pool: b.pool || "auto",
  };
  try {
    const r = await fetch("https://pumpportal.fun/api/trade-local", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    if (!r.ok) return err((await r.text()).slice(0, 300) || "PumpPortal error", r.status);
    return new Response(await r.arrayBuffer(), { status: 200, headers: { "content-type": "application/octet-stream", "cache-control": "no-store" } });
  } catch (e) {
    return err("PumpPortal unavailable", 502);
  }
}
function err(msg, status) {
  return new Response(JSON.stringify({ error: msg }), { status, headers: { "content-type": "application/json" } });
}

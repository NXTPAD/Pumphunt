// Cloudflare Pages Function: /api/rug?mint=<address>
// Fetches RugCheck's token summary server-side so the browser doesn't hit CORS limits.
export async function onRequestGet({ request }) {
  const mint = new URL(request.url).searchParams.get("mint") || "";
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) {
    return json({ error: "Invalid mint address" }, 400);
  }
  try {
    const r = await fetch(`https://api.rugcheck.xyz/v1/tokens/${mint}/report/summary`, {
      headers: { accept: "application/json", "user-agent": "NXT-Bot/1.0" },
      cf: { cacheTtl: 60, cacheEverything: true },
    });
    const body = await r.text();
    return new Response(body, {
      status: r.status,
      headers: { "content-type": "application/json", "cache-control": "public, max-age=60", "access-control-allow-origin": "*" },
    });
  } catch (e) {
    return json({ error: "RugCheck unavailable" }, 502);
  }
}
function json(o, status) {
  return new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "access-control-allow-origin": "*" } });
}
